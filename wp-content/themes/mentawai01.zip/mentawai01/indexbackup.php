<!DOCTYPE html>
<!-- saved from url=(0028)https://surfcampsiberut.com/ -->
<html lang="en-US" class=" video csspointerevents no-touchevents flexbox objectfit object-fit backgroundcliptext">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<!-- <meta name="twitter:widgets:csp" content="on">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://surfcampsiberut.com/xmlrpc.php"> -->


	<!-- This site is optimized with the Yoast SEO plugin v15.2 - https://yoast.com/wordpress/plugins/seo/ -->
	<!-- <title>Mentawai Homepage - Cheapest Surf Trip Siberut</title>
	<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
	<link rel="canonical" href="https://surfcampsiberut.com/">
	<meta property="og:locale" content="en_US">
	<meta property="og:type" content="website">
	<meta property="og:title" content="Mentawai Homepage - Cheapest Surf Trip Siberut">
	<meta property="og:url" content="https://surfcampsiberut.com/">
	<meta property="og:site_name" content="Cheapest Surf Trip Siberut">
	<meta property="article:modified_time" content="2023-07-10T08:19:13+00:00">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:label1" value="Written by">
	<meta name="twitter:data1" value="YlnCCl3e5A">
	<script src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/sdk.js" async="" crossorigin="anonymous"></script><script id="facebook-jssdk" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/sdk(1).js"></script><script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://surfcampsiberut.com/#website","url":"https://surfcampsiberut.com/","name":"Cheapest Surf Trip Mentawai at Padang Sumatera Barat Indonesia","description":"Cheapest Surf Trip Siberut At Padang Sumatera Barat","potentialAction":[{"@type":"SearchAction","target":"https://surfcampsiberut.com/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"WebPage","@id":"https://surfcampsiberut.com/#webpage","url":"https://surfcampsiberut.com/","name":"Mentawai Homepage - Cheapest Surf Trip Siberut","isPartOf":{"@id":"https://surfcampsiberut.com/#website"},"datePublished":"2016-06-17T10:24:41+00:00","dateModified":"2023-07-10T08:19:13+00:00","inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://surfcampsiberut.com/"]}]}]}</script> -->
	<!-- / Yoast SEO plugin. -->


	<!-- <link rel="dns-prefetch" href="https://fonts.googleapis.com/">
<link rel="dns-prefetch" href="https://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="Cheapest Surf Trip Siberut » Feed" href="https://surfcampsiberut.com/feed/">
<link rel="alternate" type="application/rss+xml" title="Cheapest Surf Trip Siberut » Comments Feed" href="https://surfcampsiberut.com/comments/feed/">
<link rel="alternate" type="application/rss+xml" title="Cheapest Surf Trip Siberut » Mentawai Homepage Comments Feed" href="https://surfcampsiberut.com/mentawai-homepage/feed/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/surfcampsiberut.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.14"}};
			/*! This file is auto-generated */
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/wp-emoji-release.min.js" type="text/javascript" defer=""></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;s
	padding: 0 !important;
}
</style> -->
	<!-- <link rel="stylesheet" id="zn_all_g_fonts-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/css" type="text/css" media="all"> -->
	<link rel="stylesheet" id="wp-block-library-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/style.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="kallyas-styles-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/style.css" type="text/css" media="all">
	<!-- <link rel="stylesheet" id="th-bootstrap-styles-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/bootstrap.min.css" type="text/css" media="all"> -->
	<link rel="stylesheet" id="th-theme-template-styles-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/template.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="zion-frontend-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/znb_frontend.css" type="text/css" media="all">
	<link rel="stylesheet" id="673-layout.css-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/673-layout.css" type="text/css" media="all">
	<link rel="stylesheet" id="th-theme-print-stylesheet-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/print.css" type="text/css" media="print">
	<!-- <link rel="stylesheet" id="th-theme-options-styles-css" href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/zn_dynamic.css" type="text/css" media="all"> -->
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/jquery.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/jquery-migrate.min.js"></script>

	<link rel="icon"
		href="./fileThemcropped-Logo_surfcamsiberut.com-removebg-preview-192x192.png"
		sizes="192x192">


	<!-- <link rel="https://api.w.org/" href="https://surfcampsiberut.com/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://surfcampsiberut.com/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://surfcampsiberut.com/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 5.4.14">
<link rel="shortlink" href="https://surfcampsiberut.com/">
<link rel="alternate" type="application/json+oembed" href="https://surfcampsiberut.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fsurfcampsiberut.com%2F">
<link rel="alternate" type="text/xml+oembed" href="https://surfcampsiberut.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fsurfcampsiberut.com%2F&amp;format=xml">
<meta name="theme-color" content="#ffcc00">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> -->

	<!--[if lte IE 8]>
		<script type="text/javascript">
			var $buoop = {
				vs: {i: 10, f: 25, o: 12.1, s: 7, n: 9}
			};

			$buoop.ol = window.onload;

			window.onload = function () {
				try {
					if ($buoop.ol) {
						$buoop.ol()
					}
				}
				catch (e) {
				}

				var e = document.createElement("script");
				e.setAttribute("type", "text/javascript");
				e.setAttribute("src", "https://browser-update.org/update.js");
				document.body.appendChild(e);
			};
		</script>
		<![endif]-->

	<!-- for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	<!-- Fallback for animating in viewport -->
	<!-- <noscript>
		<style type="text/css" media="screen">
			.zn-animateInViewport {visibility: visible;}
		</style>
	</noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="https://surfcampsiberut.com/wp-content/uploads/2023/07/cropped-Logo_surfcamsiberut.com-removebg-preview-32x32.png" sizes="32x32">

<link rel="apple-touch-icon" href="https://surfcampsiberut.com/wp-content/uploads/2023/07/cropped-Logo_surfcamsiberut.com-removebg-preview-180x180.png">
<meta name="msapplication-TileImage" content="https://surfcampsiberut.com/wp-content/uploads/2023/07/cropped-Logo_surfcamsiberut.com-removebg-preview-270x270.png">

<style id="fit-vids-style">.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}</style><style type="text/css" data-fbcssmodules="css:fb.css.base css:fb.css.dialog css:fb.css.iframewidget css:fb.css.customer_chat_plugin_iframe">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:'lucida grande', tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://connect.facebook.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://connect.facebook.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://connect.facebook.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://connect.facebook.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}
.fb_mpn_mobile_landing_page_slide_out{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_out_from_left{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out_from_left;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_up{animation-duration:500ms;animation-name:fb_mpn_landing_page_slide_up;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_in{animation-duration:300ms;animation-name:fb_mpn_bounce_in;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out{animation-duration:300ms;animation-name:fb_mpn_bounce_out;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out_v2{animation-duration:300ms;animation-name:fb_mpn_fade_out;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_from_left{animation-duration:300ms;animation-name:fb_bounce_in_from_left;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_from_left{animation-duration:300ms;animation-name:fb_bounce_out_from_left;transition-timing-function:ease-in}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}@keyframes fb_mpn_landing_page_slide_out{0%{margin:0 12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;margin:0 24px;width:60px}}@keyframes fb_mpn_landing_page_slide_out_from_left{0%{left:12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;left:12px;width:60px}}@keyframes fb_mpn_landing_page_slide_up{0%{bottom:0;opacity:0}100%{bottom:24px;opacity:1}}@keyframes fb_mpn_bounce_in{0%{opacity:.5;top:100%}100%{opacity:1;top:0}}@keyframes fb_mpn_fade_out{0%{bottom:30px;opacity:1}100%{bottom:0;opacity:0}}@keyframes fb_mpn_bounce_out{0%{opacity:1;top:0}100%{opacity:.5;top:100%}}@keyframes fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes fb_bounce_in_from_left{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}50%{transform:scale(1.03, 1.03);transform-origin:bottom left}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}}@keyframes fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes fb_bounce_out_from_left{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}}@keyframes slideInFromBottom{0%{opacity:.1;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}@keyframes slideInFromBottomDelay{0%{opacity:0;transform:translateY(100%)}97%{opacity:0;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}</style></head> -->

<body class="home page-template-default page page-id-673 res1170 kl-sticky-header kl-skin--light" itemscope="itemscope">


	<div class="login_register_stuff"></div><!-- end login register stuff -->
	<div id="fb-root" class=" fb_reset">
		<div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
			<div></div>
		</div>
	</div>
	<!-- <script>(function (d, s, id) {
			var js, fjs = d.getElementsByTagName(s)[0];
			if (d.getElementById(id)) {return;}
			js = d.createElement(s); js.id = id;
			js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script> -->


	<div id="page_wrapper" style="height: auto;">

		<header id="header"
			class="site-header  style13 header--sticky    headerstyle-xs--image_color  sticky-resize headerstyle--image_color site-header--absolute nav-th--light kl-center-menu sheader-sh--default header--not-sticked"
			data-original-sticky-textscheme="sh--default" role="banner" itemscope="itemscope"
			itemtype="https://schema.org/WPHeader">
			<div class="site-header-wrapper sticky-top-area">

				<div class="site-header-top-wrapper topbar-style--custom  sh--dark">

					<div class="siteheader-container topbar-full">



					</div>
				</div><!-- /.site-header-top-wrapper -->

				<div
					class="kl-top-header site-header-main-wrapper clearfix  header-no-top  header-no-bottom fxb-sm-wrap sh--default">

					<div class="container siteheader-container ">

						<div class="fxb-col fxb-basis-auto">



							<div class="fxb-row site-header-row site-header-main ">

								<div
									class="fxb-col fxb fxb-start-x fxb-center-y fxb-basis-auto fxb-grow-0  site-header-col-left site-header-main-left">
								</div>

								<div
									class="fxb-col fxb fxb-center-x fxb-center-y fxb-basis-auto site-header-col-center site-header-main-center">
									<div id="logo-container"
										class="logo-container  hasHoverMe logosize--yes zn-original-logo">
										<!-- Logo -->
										<!-- <h1 class="site-logo logo " id="logo"><a href="https://surfcampsiberut.com/"
												class="site-logo-anch"><img class="logo-img-sticky site-logo-img-sticky"
													src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/Logo_surfcamsiberut.com-floating.png"
													alt="Cheapest Surf Trip Siberut"
													title="Cheapest Surf Trip Siberut At Padang Sumatera Barat"><img
													class="logo-img site-logo-img"
													src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/Logo_surfcamsiberut.com-removebg-preview.png"
													alt="Cheapest Surf Trip Siberut"
													title="Cheapest Surf Trip Siberut At Padang Sumatera Barat"
													data-mobile-logo="https://surfcampsiberut.com/wp-content/uploads/2023/07/Logo-utama.png"></a>
										</h1>  -->
										<!-- InfoCard -->
									</div>

									<div class="sh-component main-menu-wrapper" role="navigation" itemscope="itemscope"
										itemtype="https://schema.org/SiteNavigationElement">

										<div class="zn-res-menuwrapper">
											<a href="https://surfcampsiberut.com/#"
												class="zn-res-trigger zn-menuBurger zn-menuBurger--3--s zn-menuBurger--anim1"
												id="zn-res-trigger">
												<span></span>
												<span></span>
												<span></span>
											</a>
										</div><!-- end responsive menu -->
										<div id="main-menu"
											class="main-nav mainnav--sidepanel mainnav--active-uline mainnav--pointer-dash nav-mm--light zn_mega_wrapper ">
											<ul id="menu-restaurant-menu" class="main-menu main-menu-nav zn_mega_menu ">
												<li id="menu-item-674"
													class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-674  main-menu-item-top  menu-item-even menu-item-depth-0 current_page_item current-menu-item active">
													<a href="https://surfcampsiberut.com/#eluid5a1efe31"
														class=" main-menu-link main-menu-link-top"><span>SURF
															CAMP</span></a>
													<ul class="sub-menu clearfix">
														<li id="menu-item-812"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-812  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/masokut-surf-camp-siberut-mentawai/"
																class=" main-menu-link main-menu-link-sub"><span>Masokut
																	Surf Camp Siberut Mentawai</span></a></li>
														<li id="menu-item-801"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-801  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/nyang-ebay-surf-camp/"
																class=" main-menu-link main-menu-link-sub"><span>Nyang
																	Ebay Surf Camp</span></a></li>
														<li id="menu-item-1059"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1059  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/waves-in-nyang-nyang-or-masokut-island/"
																class=" main-menu-link main-menu-link-sub"><span>Waves
																	in Nyang-Nyang or Masokut island</span></a></li>
														<li id="menu-item-1074"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1074  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/surfcamp-map/"
																class=" main-menu-link main-menu-link-sub"><span>Surfcamp
																	Map</span></a></li>
													</ul>
												</li>
												<li id="menu-item-1152"
													class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1152  main-menu-item-top  menu-item-even menu-item-depth-0">
													<a href="https://surfcampsiberut.com/#"
														class=" main-menu-link main-menu-link-top"><span>STILL AVAILABLE
															CAMP</span></a>
													<ul class="sub-menu clearfix">
														<li id="menu-item-1101"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1101  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/hts-surf-guest-katiet-mentawai/"
																class=" main-menu-link main-menu-link-sub"><span>HTs
																	Surf Guest Katiet mentawai</span></a></li>
														<li id="menu-item-1112"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1112  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/hts-katiet-surf-camp-mentawai/"
																class=" main-menu-link main-menu-link-sub"><span>HTs
																	Katiet surf camp mentawai</span></a></li>
														<li id="menu-item-1122"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1122  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/lances-surf-villa-katiet-mentawai-2/"
																class=" main-menu-link main-menu-link-sub"><span>Lance’s
																	Surf Villa katiet mentawai</span></a></li>
														<li id="menu-item-1134"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1134  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/roxy-surf-camp-mentawai/"
																class=" main-menu-link main-menu-link-sub"><span>Roxy
																	Surf camp Mentawai</span></a></li>
														<li id="menu-item-1164"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1164  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/telescope-surf-camp/"
																class=" main-menu-link main-menu-link-sub"><span>Telescope
																	Surf Camp</span></a></li>
													</ul>
												</li>
												<li class="logo-menu-wrapper is-loaded">
													<div id="logo-container"
														class="logo-container  hasHoverMe logosize--yes">
														<!-- Logo -->
														<h1 class="site-logo logo " id="logo"><a
																href="https://surfcampsiberut.com/"
																class="site-logo-anch"><img
																	class="logo-img-sticky site-logo-img-sticky"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/Logo_surfcamsiberut.com-floating.png"
																	alt="Cheapest Surf Trip Siberut"
																	title="Cheapest Surf Trip Siberut At Padang Sumatera Barat"><img
																	class="logo-img site-logo-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/Logo_surfcamsiberut.com-removebg-preview.png"
																	alt="Cheapest Surf Trip Siberut"
																	title="Cheapest Surf Trip Siberut At Padang Sumatera Barat"
																	data-mobile-logo="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/Logo-utama.png"></a>
														</h1> <!-- InfoCard -->
													</div>
												</li>
												<li id="menu-item-678"
													class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-678  main-menu-item-top  menu-item-even menu-item-depth-0">
													<a href="https://surfcampsiberut.com/#"
														class=" main-menu-link main-menu-link-top"><span>AVAILABLE
															TRIP</span></a>
													<ul class="sub-menu clearfix">
														<li id="menu-item-677"
															class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-677  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/#eluid0efaa466"
																class=" main-menu-link main-menu-link-sub"><span>Service
																	Availables</span></a>
															<ul class="sub-menu clearfix">
																<li id="menu-item-1078"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1078  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/mentawai-trekking-siberut-2/"
																		class=" main-menu-link main-menu-link-sub"><span>Mentawai
																			Tribe Siberut Island</span></a></li>
																<li id="menu-item-1146"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1146  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/padang-island-snorkling-fishing/"
																		class=" main-menu-link main-menu-link-sub"><span>Padang
																			Island Snorkling Fishing</span></a></li>
																<li id="menu-item-1148"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1148  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/traditional-house-pedicab/"
																		class=" main-menu-link main-menu-link-sub"><span>Traditional
																			House Pedicab</span></a></li>
																<li id="menu-item-1150"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1150  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/minangkabau-experience-tour/"
																		class=" main-menu-link main-menu-link-sub"><span>Minangkabau
																			Experience Tour</span></a></li>
																<li id="menu-item-1151"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1151  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/mentawai-trekking-siberut-2/"
																		class=" main-menu-link main-menu-link-sub"><span>Mentawai
																			Trekking Siberut</span></a></li>
															</ul>
														</li>
														<li id="menu-item-1153"
															class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1153  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/#"
																class=" main-menu-link main-menu-link-sub"><span>Adventure
																	Trip</span></a>
															<ul class="sub-menu clearfix">
																<li id="menu-item-1154"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1154  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/padang-motor-bike-becak-tour/"
																		class=" main-menu-link main-menu-link-sub"><span>Padang
																			Motor Bike Becak Tour</span></a></li>
																<li id="menu-item-1155"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1155  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/kerinci-tour/"
																		class=" main-menu-link main-menu-link-sub"><span>Kerinci
																			Tour</span></a></li>
																<li id="menu-item-1156"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1156  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/kerinci-view-cottage/"
																		class=" main-menu-link main-menu-link-sub"><span>Kerinci
																			View Cottage</span></a></li>
																<li id="menu-item-1158"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1158  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/rent-motor-bike/"
																		class=" main-menu-link main-menu-link-sub"><span>Rent
																			Motor Bike</span></a></li>
																<li id="menu-item-1159"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1159  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/rent-surf-board/"
																		class=" main-menu-link main-menu-link-sub"><span>Rent
																			Surf Board</span></a></li>
																<li id="menu-item-1160"
																	class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-1160  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2">
																	<a href="https://surfcampsiberut.com/penginapan-yani-padang/"
																		class=" main-menu-link main-menu-link-sub"><span>Penginapan
																			Yani Padang</span></a></li>
															</ul>
														</li>
													</ul>
												</li>
												<li id="menu-item-679"
													class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-679  main-menu-item-top  menu-item-even menu-item-depth-0">
													<a href="https://surfcampsiberut.com/#"
														class=" main-menu-link main-menu-link-top"><span>OTHER</span></a>
													<ul class="sub-menu clearfix">
														<li id="menu-item-755"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-755  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/prices/"
																class=" main-menu-link main-menu-link-sub"><span>Prices</span></a>
														</li>
														<li id="menu-item-971"
															class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-971  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://surfcampsiberut.com/payments/"
																class=" main-menu-link main-menu-link-sub"><span>Payments</span></a>
														</li>
														<li id="menu-item-675"
															class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-675  main-menu-item-sub  menu-item-odd menu-item-depth-1">
															<a href="https://wa.me/6281374006060"
																class=" main-menu-link main-menu-link-sub"><span>Book
																	Now</span></a></li>
													</ul>
												</li>
											</ul>
										</div>
									</div>
									<!-- end main_menu -->
								</div>

								<div
									class="fxb-col fxb fxb-end-x fxb-center-y fxb-basis-auto fxb-grow-0  site-header-col-right site-header-main-right">

									<div
										class="fxb-col fxb fxb-end-x fxb-center-y fxb-basis-auto fxb-grow-0  site-header-main-right-top">
									</div>


								</div>

							</div><!-- /.site-header-main -->


						</div>

					</div><!-- /.siteheader-container -->

				</div><!-- /.site-header-main-wrapper -->



			</div><!-- /.site-header-wrapper -->
		</header>
		<div class="zn_pb_wrapper clearfix zn_sortable_content" data-droplevel="0">
			<section class="zn_section eluid6c765147     section-sidemargins    zn_section--relative section--no "
				id="eluid6c765147">

				<div class="zn-bgSource ">
					<div class="zn-bgSource-image"
						style="background-image:url(https://surfcampsiberut.com/wp-content/uploads/2023/07/beach-fun.jpg);background-repeat:no-repeat;background-position:left top;background-size:cover;background-attachment:scroll">
					</div>
				</div>
				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid4ebdbad4            col-md-6 col-sm-6   znColumnElement" id="eluid4ebdbad4">


							<div
								class="znColumnElement-innerWrapper-eluid4ebdbad4 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid1293c1c0 ">
										<h1 class="tbk__title" itemprop="headline">Join the Mentawai Surf Camp Barrel.
											Start your Surf Adventure.</h1>
										<h2 class="tbk__subtitle" itemprop="alternativeHeadline">-</h2>
									</div>
									<div id="eluid64a95d22" class="zn_buttons_element eluid64a95d22 text-center "><a
											href="https://surfcampsiberut.com/#eluid703dd445" id="eluid64a95d220"
											class="eluid64a95d220 btn-element btn-element-0 btn  btn-fullcolor btn-custom-color btn-sm  zn_dummy_value btn-icon--before btn--rounded"
											data-target="smoothscroll" itemprop="url"><span>PRICE PACKAGE</span></a>
									</div>
								</div>
							</div>


						</div>

						<div class="eluidcda2ec81            col-md-6 col-sm-6   znColumnElement" id="eluidcda2ec81">


							<div
								class="znColumnElement-innerWrapper-eluidcda2ec81 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent"> </div>
							</div>


						</div>

						<div class="eluid81ae022f            col-md-12 col-sm-12   znColumnElement" id="eluid81ae022f">


							<div
								class="znColumnElement-innerWrapper-eluid81ae022f znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div class="th-spacer clearfix eluidba787014     "></div>
								</div>
							</div>


						</div>

						<div class="eluid6762db8e            col-md-3 col-sm-3   znColumnElement" id="eluid6762db8e">


							<div
								class="znColumnElement-innerWrapper-eluid6762db8e znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluideed991d9 ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Island</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>Mentawai Islands is the best place on
													earth for surfing with world class waves and Nyang-Nyang Island in
													its heart.</strong></p>
										</div>
									</div>
								</div>
							</div>


						</div>

						<div class="eluid86459c6a            col-md-3 col-sm-3   znColumnElement" id="eluid86459c6a">


							<div
								class="znColumnElement-innerWrapper-eluid86459c6a znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluid5b1c2c91 ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Waves</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>waves are in walking distance with surf
													spot in front of our camp and many more waves by boat.</strong></p>
										</div>
									</div>
								</div>
							</div>


						</div>

						<div class="eluide8056e66            col-md-3 col-sm-3   znColumnElement" id="eluide8056e66">


							<div
								class="znColumnElement-innerWrapper-eluide8056e66 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluid05a7caa5 ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Resort</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>Beachfront wooden bungalows in Mentawai
													style surrounded by nature are managed by lovely locals.</strong>
											</p>
										</div>
									</div>
								</div>
							</div>


						</div>

						<div class="eluidf91a2408            col-md-3 col-sm-3   znColumnElement" id="eluidf91a2408">


							<div
								class="znColumnElement-innerWrapper-eluidf91a2408 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluid869ab51d ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Food</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>Three delicious meals a day with
													unlimited coffee, tea and water within all our packages will never
													leave you hungry.</strong></p>
										</div>
									</div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid5a1efe31     section-sidemargins    section--no " id="eluid5a1efe31">


				<div class="zn_section_size full_width zn-section-height--auto zn-section-content_algn--middle ">

					<div class="row gutter-0">

						<div class="eluid94cd950d            col-md-6 col-sm-6   znColumnElement" id="eluid94cd950d">


							<div
								class="znColumnElement-innerWrapper-eluid94cd950d znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="zn_custom_container eluid2683b90b  smart-cnt--default   clearfix">
										<div class="zn_col_eq_first">
											<div class="row zn_col_container-smart_container gutter-0">

												<div class="eluidc9f0374e            col-md-11 col-sm-11   znColumnElement"
													id="eluidc9f0374e">


													<div
														class="znColumnElement-innerWrapper-eluidc9f0374e znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

														<div class="znColumnElement-innerContent">
															<div
																class="th-spacer clearfix eluid374f0b28   hidden-sm hidden-xs ">
															</div>
															<div
																class="kl-title-block clearfix tbk--text- tbk--left text-left tbk-symbol--  tbk-icon-pos--after-title eluid9fc3ae52 ">
																<h2 class="tbk__title" itemprop="headline">About</h2>
																<div class="tbk__text">
																	<p>The west Sumatra have the best trip travel,
																		Surfing Mentawai,Trekking jungle
																		Mentawai,Snorkelling Around Padang Islands,Tour
																		Around West Sumatra to be found.</p>
																	<p>Let Explore West Sumatra: Come and enjoy our
																		heavenly travel destination. The west Sumatra
																		have the best trip travel, Surfing
																		Mentawai,Trekking jungle Mentawai,Snorkelling
																		Around Padang Islands,Tour Around West Sumatra
																		to be found.What are you waiting for?
																		Come,…come. Don’t refuse my invitation. It will
																		be for sure, the best ride of your life!</p>
																</div>
															</div>
															<div
																class="th-spacer clearfix eluidd17db177 hidden-lg hidden-md   ">
															</div>
														</div>
													</div>


												</div>
											</div>
										</div>
									</div><!-- /.zn_custom_container -->


								</div>
							</div>


						</div>

						<div class="eluidd861c292            col-md-6 col-sm-6   znColumnElement" id="eluidd861c292">


							<div
								class="znColumnElement-innerWrapper-eluidd861c292 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="media-container eluid366dbff3  media-container--type- kl-overlay-none  ">

										<div class="zn-bgSource ">
											<div class="zn-bgSource-image"
												style="background-image:url(https://mentawai-surfingbarrels.com/wp-content/uploads/2023/03/banner.jpg);background-repeat:repeat;background-position:center center;background-size:cover;background-attachment:scroll">
											</div>
										</div>
									</div>
									<div class="th-spacer clearfix eluid0d29baeb hidden-lg hidden-md hidden-sm  "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section
				class="zn_section eluid7f254383   zn_parallax  section-sidemargins    zn_section--relative section--no "
				id="eluid7f254383">

				<div class="zn-bgSource zn-bgSource-imageParallax js-znParallax is-fixed"
					style="height: 230px; width: 1903px; transform: translate3d(0px, 882.375px, 0px);">
					<div class="zn-bgSource-image"
						style="background-image: url(&quot;https://mentawai-surfingbarrels.com/wp-content/uploads/2023/03/mentawai-islands.jpg&quot;); background-repeat: no-repeat; background-position: center center; background-size: cover; transform: translate3d(0px, -679px, 0px);">
					</div>
					<div class="zn-bgSource-overlay" style="background-color:rgba(53,53,53,0.55)"></div>
				</div>
				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluidf0600da9            col-md-12 col-sm-12   znColumnElement" id="eluidf0600da9">


							<div
								class="znColumnElement-innerWrapper-eluidf0600da9 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluidaf6de692 ">
										<h1 class="tbk__title" itemprop="headline">Best Location in Mentawai</h1>
									</div>
									<div class="image-boxes imgbox-simple eluid44d8ea6b ">
										<div class="image-boxes-holder imgboxes-wrapper u-mb-0  ">
											<div class="image-boxes-img-wrapper img-align-center"><img
													class="image-boxes-img img-responsive "
													src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/3-flowers.png" alt="" title=""></div>
										</div>
									</div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluidcde410de  u-zindex-1   section-sidemargins    section--no "
				id="eluidcde410de">


				<div
					class="zn_section_size container custom_width zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid410f5aac            col-md-6 col-sm-5 col-xs-12  znColumnElement"
							id="eluid410f5aac">


							<div
								class="znColumnElement-innerWrapper-eluid410f5aac znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="zn_custom_container eluid3aebeaed  smart-cnt--default   clearfix">

										<div class="row zn_col_container-smart_container ">

											<div class="eluid6237d91f            col-md-12 col-sm-12   znColumnElement"
												id="eluid6237d91f">


												<div
													class="znColumnElement-innerWrapper-eluid6237d91f znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

													<div class="znColumnElement-innerContent">
														<div class="el-videobox eluid7826443b  el-videobox-Type-modal">
															<div class="fluid-width-video-wrapper"
																style="padding-top: 56.2353%;">
																<!-- <iframe class=""
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/CUsO7bmvaCE.html"
																	allowfullscreen="" id="fitvid0"></iframe> -->
																</div>
														</div>
													</div>
												</div>


											</div>
										</div>
									</div><!-- /.zn_custom_container -->


								</div>
							</div>


						</div>

						<div class="eluid6cf61102  col-lg-offset-1 col-md-offset-2 col-sm-offset-2        col-md-5 col-sm-5 col-xs-12  znColumnElement"
							id="eluid6cf61102">


							<div
								class="znColumnElement-innerWrapper-eluid6cf61102 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="th-spacer clearfix eluidd4be43d9  hidden-md hidden-sm hidden-xs "></div>
									<div
										class="kl-title-block clearfix tbk--text- tbk--left text-left tbk-symbol--  tbk-icon-pos--after-title eluid8f8c0381 ">
										<h2 class="tbk__title" itemprop="headline">Taste the vibes of Surf Camp
											Mentawais </h2>
										<div class="tbk__text">
											<p></p>
											<p>Welcome to Surf Camp. Enjoy your surf holiday while we take care of the
												rest.<br>
												The camp at the beach front of Island with traditional wooden bungalows
												is managed by a warmhearted local family. Be prepared to be treated like
												a family member and to be taken care of for an unforgettable stay.<br>
												Hospitality&nbsp;at its finest paired with a&nbsp;world class
												surf&nbsp;experience on a heavenly island is what you can expect.</p>
											<p></p>
										</div>
									</div>
									<div id="eluid107643e2" class="zn_buttons_element eluid107643e2 text-left "><a
											href="https://surfcampsiberut.com/#eluid0efaa466" id="eluid107643e20"
											class="eluid107643e20 btn-element btn-element-0 btn  btn-lined lined-dark btn-lg btn-third zn_dummy_value btn-icon--before btn--square"
											data-target="smoothscroll" itemprop="url"><span>ORDER NOW</span></a></div>
									<div class="th-spacer clearfix eluid32505abb     "></div>
									<div class="th-spacer clearfix eluidef34d963  hidden-md hidden-sm hidden-xs "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section
				class="zn_section eluid88b1cfba   zn_parallax  section-sidemargins    zn_section--relative section--no "
				id="eluid88b1cfba">

				<div class="zn-bgSource zn-bgSource-imageParallax js-znParallax is-fixed"
					style="height: 240px; width: 1903px; transform: translate3d(0px, 879.828px, 0px);">
					<div class="zn-bgSource-image"
						style="background-image: url(&quot;https://mentawai-surfingbarrels.com/wp-content/uploads/2023/03/mentawai-islands.jpg&quot;); background-repeat: no-repeat; background-position: center center; background-size: cover; transform: translate3d(0px, -677px, 0px);">
					</div>
					<div class="zn-bgSource-overlay" style="background-color:rgba(53,53,53,0.3)"></div>
				</div>
				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid82e08d3b            col-md-12 col-sm-12   znColumnElement" id="eluid82e08d3b">


							<div
								class="znColumnElement-innerWrapper-eluid82e08d3b znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluidb4106c53 ">
										<h1 class="tbk__title" itemprop="headline">BEST SERVICE EVER</h1>
									</div>
									<div class="image-boxes imgbox-simple eluidb3de4226 ">
										<div class="image-boxes-holder imgboxes-wrapper u-mb-0  ">
											<div class="image-boxes-img-wrapper img-align-center"><img
													class="image-boxes-img img-responsive "
													src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/3-flowers.png" alt="" title=""></div>
										</div>
									</div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid7c57ccf6  u-zindex-1   section-sidemargins    section--no "
				id="eluid7c57ccf6">


				<div
					class="zn_section_size container custom_width zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid69ebacde            col-md-6 col-sm-5 col-xs-12  znColumnElement"
							id="eluid69ebacde">


							<div
								class="znColumnElement-innerWrapper-eluid69ebacde znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="zn_custom_container eluidc0226fbc  smart-cnt--default   clearfix">

										<div class="row zn_col_container-smart_container ">

											<div class="eluide25fb3dd            col-md-12 col-sm-12   znColumnElement"
												id="eluide25fb3dd">


												<div
													class="znColumnElement-innerWrapper-eluide25fb3dd znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

													<div class="znColumnElement-innerContent">
														<div class="eluidc6631c07  zn-SliderEl clearfix zn-SliderEl--view"
															id="eluidc6631c07">
															<div
																class="zn-SliderNav zn-SliderNav--pos-middle zn-SliderNav--style1 zn-SliderNav--size-normal zn-SliderNav--round-yes zn-SliderNav--theme-dark">
																<span class="znSlickNav-arr znSlickNav-prev slick-arrow"
																	style="display: block;"><svg viewBox="0 0 256 256">
																		<polyline fill="none" stroke="black"
																			stroke-width="16" stroke-linejoin="round"
																			stroke-linecap="round"
																			points="184,16 72,128 184,240"></polyline>
																	</svg></span><span
																	class="znSlickNav-arr znSlickNav-next slick-arrow"
																	style="display: block;"><svg viewBox="0 0 256 256">
																		<polyline fill="none" stroke="black"
																			stroke-width="16" stroke-linejoin="round"
																			stroke-linecap="round"
																			points="72,16 184,128 72,240"></polyline>
																	</svg></span></div>
															<div class="zn-Slider zn-Slider-eluidc6631c07 zn-Slider--cols1 js-slick mfp-gallery mfp-gallery--misc slick-initialized slick-slider slickSlider--activated"
																data-slick="{&quot;slidesToShow&quot;:1,&quot;responsive&quot;:[],&quot;autoplay&quot;:true,&quot;appendArrows&quot;:&quot;.eluidc6631c07 .zn-SliderNav&quot;}">
																<div class="slick-list draggable">
																	<div class="slick-track"
																		style="opacity: 1; width: 5390px; transform: translate3d(-1540px, 0px, 0px);">
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="-1"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg"
																					title="pantai_mapadegat_kepulauan_mentawai"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="433"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/pantai_mapadegat_kepulauan_mentawai-768x433.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-768x433.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-280x158.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg 790w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide"
																			data-title="" data-slick-index="0"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg"
																					title="5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="432"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1024x576.jpg 1024w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-280x157.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1170x658.jpg 1170w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg 1265w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-current slick-active slick-item--activated"
																			data-title="" data-slick-index="1"
																			aria-hidden="false" style="width: 770px;"
																			tabindex="0">
																			<div class="zn-Slider-itemInner"><a
																					href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																					title="kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="0"><img width="700"
																						height="393"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg 700w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-300x168.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-280x157.jpg 280w"
																						sizes="(max-width: 700px) 100vw, 700px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide"
																			data-title="" data-slick-index="2"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg"
																					title="pantai_mapadegat_kepulauan_mentawai"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="433"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/pantai_mapadegat_kepulauan_mentawai-768x433.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-768x433.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-280x158.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg 790w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="3"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg"
																					title="5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="432"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1024x576.jpg 1024w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-280x157.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1170x658.jpg 1170w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg 1265w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="4"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																					title="kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="700"
																						height="393"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg 700w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-300x168.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-280x157.jpg 280w"
																						sizes="(max-width: 700px) 100vw, 700px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="5"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg"
																					title="pantai_mapadegat_kepulauan_mentawai"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="433"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/pantai_mapadegat_kepulauan_mentawai-768x433.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-768x433.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-280x158.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg 790w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>


											</div>
										</div>
									</div><!-- /.zn_custom_container -->


								</div>
							</div>


						</div>

						<div class="eluidc029ac95  col-lg-offset-1 col-md-offset-2 col-sm-offset-2        col-md-5 col-sm-5 col-xs-12  znColumnElement"
							id="eluidc029ac95">


							<div
								class="znColumnElement-innerWrapper-eluidc029ac95 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="th-spacer clearfix eluid8cdb7457  hidden-md hidden-sm hidden-xs "></div>
									<div
										class="kl-title-block clearfix tbk--text- tbk--left text-left tbk-symbol--  tbk-icon-pos--after-title eluid05a5a489 ">
										<h2 class="tbk__title" itemprop="headline">Touch the atmosphere of Mentawai
											Islands.</h2>
										<div class="tbk__text">
											<p></p>
											<p>We have surf camp that serve either as shared rooms or can be booked as
												private rooms and Dorm Western style toilets and showers are shared.
												Mosquito nets, fans, towels and sockets are provided.<br>
												Our family knows the waves, the winds, the weather and the islands
												better than anybody else, since we were living here for generations as
												fishermen, basically growing up in the waters.<br>
												And it seems like many of our guests like the way we treat them since
												they return to us regularly for another stay. We are very proud of that!
											</p>
											<p></p>
										</div>
									</div>
									<div id="eluid836349e2" class="zn_buttons_element eluid836349e2 text-left "><a
											href="https://wa.me/6281374006060" id="eluid836349e20"
											class="eluid836349e20 btn-element btn-element-0 btn  btn-lined lined-dark btn-lg btn-third zn_dummy_value btn-icon--before btn--square"
											data-target="smoothscroll" itemprop="url"><span>ORDER NOW</span></a></div>
									<div class="th-spacer clearfix eluided3ac01f     "></div>
									<div class="th-spacer clearfix eluidf84d1c90  hidden-md hidden-sm hidden-xs "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid301682de     section-sidemargins    section--no " id="eluid301682de">


				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluidb444505a            col-md-12 col-sm-12   znColumnElement" id="eluidb444505a">


							<div
								class="znColumnElement-innerWrapper-eluidb444505a znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid316859a4 ">
										<h2 class="tbk__title" itemprop="headline">Feel the words of our guests.</h2>
									</div>
								</div>
							</div>


						</div>

						<div class="eluidcbf748b5  col-lg-offset-3          col-md-6 col-sm-6   znColumnElement"
							id="eluidcbf748b5">


							<div
								class="znColumnElement-innerWrapper-eluidcbf748b5 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid4a1d95f9 ">
										<h3 class="tbk__title" itemprop="headline">TESTIMONY</h3>
									</div>
									<div
										class="testimonials-carousel tst-carousel eluidef1b9cc4  tstsld--light element-scheme--light">
										<div class="tst-carousel-controls"><span
												class="znSlickNav-arr znSlickNav-prev slick-arrow"
												style="display: inline;"><svg viewBox="0 0 256 256">
													<polyline fill="none" stroke="black" stroke-width="16"
														stroke-linejoin="round" stroke-linecap="round"
														points="184,16 72,128 184,240"></polyline>
												</svg></span><span class="znSlickNav-arr znSlickNav-next slick-arrow"
												style="display: inline;"><svg viewBox="0 0 256 256">
													<polyline fill="none" stroke="black" stroke-width="16"
														stroke-linejoin="round" stroke-linecap="round"
														points="72,16 184,128 72,240"></polyline>
												</svg></span></div>
										<ul class="tst-carousel-list js-slick slick-initialized slick-slider"
											data-slick="{&quot;infinite&quot;:true,&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1,&quot;autoplay&quot;:true,&quot;autoplaySpeed&quot;:&quot;2500&quot;,&quot;arrows&quot;:true,&quot;appendArrows&quot;:&quot;.eluidef1b9cc4 .tst-carousel-controls&quot;,&quot;dots&quot;:false}">
											<div class="slick-list draggable">
												<div class="slick-track"
													style="opacity: 1; width: 2775px; transform: translate3d(-1665px, 0px, 0px); transition: transform 500ms ease 0s;">
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-cloned"
														data-slick-index="-1" aria-hidden="true" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>If you want to live a
																good real experience into mentawai, this is the place to
																stay. Good food, good acomodation into an awesome
																atmosphere. Aldi the owner will make sure you feel like
																home! Really recommend it.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/STUDIO-SHODWE.-SURFING-CLUB-AND-APPARELS-7-1-e1678370187674-40x40_c.png"
																	width="40" height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Hegoi</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-current slick-active"
														data-slick-index="0" aria-hidden="false" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>I felt at home. They
																took us surfing everywhere, they taught us all the ways
																through the jungle, they waited for us all day with
																freshly made food, they took care of us and our things,
																they motivated us to go fishing, they went to buy things
																on another island. They went fishing every day, they
																helped me repair my board and above all, they always had
																tremendous energy all the time, a total commitment to
																this family.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/juan-40x40_c.jpg" width="40"
																	height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Raul</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide"
														data-slick-index="1" aria-hidden="true" tabindex="0"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>If you want to live a
																good real experience into mentawai, this is the place to
																stay. Good food, good acomodation into an awesome
																atmosphere. Aldi the owner will make sure you feel like
																home! Really recommend it.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/STUDIO-SHODWE.-SURFING-CLUB-AND-APPARELS-7-1-e1678370187674-40x40_c.png"
																	width="40" height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Hegoi</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-cloned"
														data-slick-index="2" aria-hidden="true" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>I felt at home. They
																took us surfing everywhere, they taught us all the ways
																through the jungle, they waited for us all day with
																freshly made food, they took care of us and our things,
																they motivated us to go fishing, they went to buy things
																on another island. They went fishing every day, they
																helped me repair my board and above all, they always had
																tremendous energy all the time, a total commitment to
																this family.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/juan-40x40_c.jpg" width="40"
																	height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Raul</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-cloned"
														data-slick-index="3" aria-hidden="true" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>If you want to live a
																good real experience into mentawai, this is the place to
																stay. Good food, good acomodation into an awesome
																atmosphere. Aldi the owner will make sure you feel like
																home! Really recommend it.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/STUDIO-SHODWE.-SURFING-CLUB-AND-APPARELS-7-1-e1678370187674-40x40_c.png"
																	width="40" height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Hegoi</h5>
														</div>
													</li>
												</div>
											</div>
										</ul>
									</div>
									<div class="th-spacer clearfix eluidf95400fd     "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid703dd445     section-sidemargins    section--no " id="eluid703dd445">


				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid9cec0bc6            col-md-12 col-sm-12   znColumnElement" id="eluid9cec0bc6">


							<div
								class="znColumnElement-innerWrapper-eluid9cec0bc6 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid7639ee48 ">
										<h2 class="tbk__title" itemprop="headline">Book now</h2>
										<h4 class="tbk__subtitle" itemprop="alternativeHeadline">You have chosen a
											package and want to stay with us? Or you still have questions?

											Contact us.</h4>
									</div>
									<div id="eluidda12940e" class="zn_buttons_element eluidda12940e text-center "><a
											href="tel:+6281374006060" id="eluidda12940e0"
											class="eluidda12940e0 btn-element btn-element-0 btn  btn-fullcolor btn-custom-color btn-md  zn_dummy_value btn-icon--before btn--rounded"
											target="_blank" rel="noopener" itemprop="url"><span class="btn-element-icon"
												data-zniconfam="glyphicons_halflingsregular"
												data-zn_icon=""></span><span>+62 813-7400-6060</span></a></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<div class="eluidda27f7d1 ">
				<section class="zn_section eluid62b729bd     section-sidemargins    section--no " id="eluid62b729bd">


					<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

						<div class="row ">

							<div class="eluid6c433df4  col-lg-offset-2 col-md-offset-2 col-sm-offset-2        col-md-8 col-sm-8   znColumnElement"
								id="eluid6c433df4">


								<div
									class="znColumnElement-innerWrapper-eluid6c433df4 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

									<div class="znColumnElement-innerContent">
										<div class="image-boxes imgbox-simple eluid746798aa ">
											<div class="image-boxes-holder imgboxes-wrapper u-mb-0  ">
												<div class="image-boxes-img-wrapper img-align-center"><img
														class="image-boxes-img img-responsive "
														src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/Logo-utama.png" alt="" title="Logo-utama">
												</div>
											</div>
										</div>
										<div
											class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid33bb2c5d ">
											<h1 class="tbk__title" itemprop="headline">Join us.</h1>
											<h2 class="tbk__subtitle" itemprop="alternativeHeadline">You like what you
												see and want to stay with us? Or you still have questions?

												We handle all our bookings and communication via WhatsApp. To make it
												simple.

												Feel free to reach out to us.</h2>
										</div>
									</div>
								</div>


							</div>

							<div class="eluide3bdf3cb  col-lg-offset-3 col-md-offset-3 col-sm-offset-3        col-md-6 col-sm-6   znColumnElement"
								id="eluide3bdf3cb">


								<div
									class="znColumnElement-innerWrapper-eluide3bdf3cb znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

									<div class="znColumnElement-innerContent">
										<div id="eluid3b30cf52" class="zn_buttons_element eluid3b30cf52 text-center "><a
												href="https://wa.me/6281374006060" id="eluid3b30cf520"
												class="eluid3b30cf520 btn-element btn-element-0 btn  btn-fullcolor btn-custom-color btn-sm  zn_dummy_value btn-icon--before btn--rounded"
												data-target="smoothscroll" itemprop="url"><span>CONTACT US</span></a>
										</div>
									</div>
								</div>


							</div>

							<div class="eluidcf32a6e9            col-md-12 col-sm-12   znColumnElement"
								id="eluidcf32a6e9">


								<div
									class="znColumnElement-innerWrapper-eluidcf32a6e9 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

									<div class="znColumnElement-innerContent">
										<div class="th-spacer clearfix eluid7fb3da86     "></div>
									</div>
								</div>


							</div>

							<div class="eluid97524b63            col-md-12 col-sm-12   znColumnElement"
								id="eluid97524b63">


								<div
									class="znColumnElement-innerWrapper-eluid97524b63 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

									<div class="znColumnElement-innerContent">
										<div
											class="elm-socialicons eluid7f635b6e  text-center sc-icon--center elm-socialicons--light element-scheme--light">
											<ul class="elm-social-icons sc--clean sh--rounded sc-lay--normal clearfix">
												<li class="elm-social-icons-item"><a
														href="https://surfcampsiberut.com/#"
														class="elm-sc-link elm-sc-icon-0" target="_self"
														itemprop="url"><span class="elm-sc-icon "
															data-zniconfam="kl-social-icons"
															data-zn_icon=""></span></a>
													<div class="clearfix"></div>
												</li>
												<li class="elm-social-icons-item"><a
														href="https://surfcampsiberut.com/#"
														class="elm-sc-link elm-sc-icon-1" target="_self"
														itemprop="url"><span class="elm-sc-icon "
															data-zniconfam="kl-social-icons"
															data-zn_icon=""></span></a>
													<div class="clearfix"></div>
												</li>
												<li class="elm-social-icons-item"><a
														href="https://surfcampsiberut.com/#"
														class="elm-sc-link elm-sc-icon-2" target="_self"
														itemprop="url"><span class="elm-sc-icon "
															data-zniconfam="kl-social-icons"
															data-zn_icon=""></span></a>
													<div class="clearfix"></div>
												</li>
												<li class="elm-social-icons-item"><a
														href="https://surfcampsiberut.com/#"
														class="elm-sc-link elm-sc-icon-3" target="_self"
														itemprop="url"><span class="elm-sc-icon "
															data-zniconfam="kl-social-icons"
															data-zn_icon=""></span></a>
													<div class="clearfix"></div>
												</li>
											</ul>
										</div>
									</div>
								</div>


							</div>

							<div class="eluid04c196e1            col-md-12 col-sm-12   znColumnElement"
								id="eluid04c196e1">


								<div
									class="znColumnElement-innerWrapper-eluid04c196e1 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

									<div class="znColumnElement-innerContent">
										<div
											class="elm-custommenu clearfix eluid140d1057  text-center elm-custommenu--h1">
											<ul id="eluid140d1057"
												class="elm-cmlist clearfix elm-cmlist--skin-dark element-scheme--dark zn_dummy_value elm-cmlist--h1 elm-cmlist--dropDown nav-with-smooth-scroll">
												<li
													class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-674 current_page_item current-menu-item active">
													<a href="https://surfcampsiberut.com/#eluid5a1efe31"><span>SURF
															CAMP</span></a></li>
												<li
													class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1152">
													<a href="https://surfcampsiberut.com/#"><span>STILL AVAILABLE
															CAMP</span></a></li>
												<li
													class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-678">
													<a href="https://surfcampsiberut.com/#"><span>AVAILABLE
															TRIP</span></a></li>
												<li
													class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-679">
													<a href="https://surfcampsiberut.com/#"><span>OTHER</span></a></li>
											</ul>
										</div>
									</div>
								</div>


							</div>

						</div>
					</div>

				</section>


				<section class="zn_section eluid22868419     section-sidemargins    section--no " id="eluidb0a6f970">


					<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

						<div class="row ">

							<div class="eluid6a1e625c            col-md-7 col-sm-7   znColumnElement"
								id="eluideb6da656">


								<div
									class="znColumnElement-innerWrapper-eluid6a1e625c znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

									<div class="znColumnElement-innerContent">
										<div class="zn_text_box eluid182ce248  zn_text_box-light element-scheme--light">
											<p><span style="font-size: 12px;"><span
														style="color: #ffffff; text-transform: uppercase;">© 2022 <span
															style="color: #ff0000;"><a style="color: #ffffff;"
																href="https://mentawai-surfingbarrels.com/"
																target="">Surf Camp Siberut</a></span>&nbsp;| All rights
														reserved</span> </span><span
													style="color: #999999;">.&nbsp;</span><span
													style="font-size: 12px;"><span
														style="color: #ffffff; text-transform: uppercase;">Theme Powered
														by <a href="https://puplas.com/"><span
																style="color: #ffffff; text-transform: uppercase;">PUPLAS.COM</span></a>.</span></span>
											</p>
										</div>
									</div>
								</div>


							</div>

						</div>
					</div>

				</section>


			</div>
		</div>
	</div><!-- end page_wrapper -->

	<a href="https://surfcampsiberut.com/#" id="totop" class="u-trans-all-2s js-scroll-event" data-forch="300"
		data-visibleclass="on--totop">TOP</a>

	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/plugins.min.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/scrollmagic.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var zn_do_login = { "ajaxurl": "\/wp-admin\/admin-ajax.php", "add_to_cart_text": "Item Added to cart!" };
		var ZnThemeAjax = { "ajaxurl": "\/wp-admin\/admin-ajax.php", "zn_back_text": "Back", "zn_color_theme": "light", "res_menu_trigger": "992", "top_offset_tolerance": "", "logout_url": "https:\/\/surfcampsiberut.com\/wp-login.php?action=logout&redirect_to=https%3A%2F%2Fsurfcampsiberut.com&_wpnonce=0e7e1658d7" };
		var ZnSmoothScroll = { "type": "yes", "touchpadSupport": "no" };
		/* ]]> */
	</script>
	<!-- <script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/znscript.min.js"></script> -->
	<!-- <script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/SmoothScroll.min.js"></script> -->
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/slick.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var ZionBuilderFrontend = { "allow_video_on_mobile": "" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/znpb_frontend.bundle.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/wp-embed.min.js"></script>
	<svg style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1"
		xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
		<defs>

			<symbol id="icon-znb_close-thin" viewBox="0 0 100 100">
				<path
					d="m87.801 12.801c-1-1-2.6016-1-3.5 0l-33.801 33.699-34.699-34.801c-1-1-2.6016-1-3.5 0-1 1-1 2.6016 0 3.5l34.699 34.801-34.801 34.801c-1 1-1 2.6016 0 3.5 0.5 0.5 1.1016 0.69922 1.8008 0.69922s1.3008-0.19922 1.8008-0.69922l34.801-34.801 33.699 33.699c0.5 0.5 1.1016 0.69922 1.8008 0.69922 0.69922 0 1.3008-0.19922 1.8008-0.69922 1-1 1-2.6016 0-3.5l-33.801-33.699 33.699-33.699c0.89844-1 0.89844-2.6016 0-3.5z">
				</path>
			</symbol>


			<symbol id="icon-znb_play" viewBox="0 0 22 28">
				<path
					d="M21.625 14.484l-20.75 11.531c-0.484 0.266-0.875 0.031-0.875-0.516v-23c0-0.547 0.391-0.781 0.875-0.516l20.75 11.531c0.484 0.266 0.484 0.703 0 0.969z">
				</path>
			</symbol>

		</defs>
	</svg>


	<iframe src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/start.html" style="display:none"></iframe>
</body>

</html>