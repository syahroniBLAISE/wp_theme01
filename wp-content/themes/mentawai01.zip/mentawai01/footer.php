

<a href="https://surfcampsiberut.com/#" id="totop" class="u-trans-all-2s js-scroll-event" data-forch="300"
		data-visibleclass="on--totop">TOP</a>

	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/plugins.min.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/scrollmagic.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var zn_do_login = { "ajaxurl": "\/wp-admin\/admin-ajax.php", "add_to_cart_text": "Item Added to cart!" };
		var ZnThemeAjax = { "ajaxurl": "\/wp-admin\/admin-ajax.php", "zn_back_text": "Back", "zn_color_theme": "light", "res_menu_trigger": "992", "top_offset_tolerance": "", "logout_url": "https:\/\/surfcampsiberut.com\/wp-login.php?action=logout&redirect_to=https%3A%2F%2Fsurfcampsiberut.com&_wpnonce=0e7e1658d7" };
		var ZnSmoothScroll = { "type": "yes", "touchpadSupport": "no" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/znscript.min.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/SmoothScroll.min.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/slick.min.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/scroll.js"></script>
	
	<script type="text/javascript">
		/* <![CDATA[ */
		var ZionBuilderFrontend = { "allow_video_on_mobile": "" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/znpb_frontend.bundle.js"></script>
	<script type="text/javascript" src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/wp-embed.min.js"></script>
	<svg style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1"
		xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
		<defs>

			<symbol id="icon-znb_close-thin" viewBox="0 0 100 100">
				<path
					d="m87.801 12.801c-1-1-2.6016-1-3.5 0l-33.801 33.699-34.699-34.801c-1-1-2.6016-1-3.5 0-1 1-1 2.6016 0 3.5l34.699 34.801-34.801 34.801c-1 1-1 2.6016 0 3.5 0.5 0.5 1.1016 0.69922 1.8008 0.69922s1.3008-0.19922 1.8008-0.69922l34.801-34.801 33.699 33.699c0.5 0.5 1.1016 0.69922 1.8008 0.69922 0.69922 0 1.3008-0.19922 1.8008-0.69922 1-1 1-2.6016 0-3.5l-33.801-33.699 33.699-33.699c0.89844-1 0.89844-2.6016 0-3.5z">
				</path>
			</symbol>


			<symbol id="icon-znb_play" viewBox="0 0 22 28">
				<path
					d="M21.625 14.484l-20.75 11.531c-0.484 0.266-0.875 0.031-0.875-0.516v-23c0-0.547 0.391-0.781 0.875-0.516l20.75 11.531c0.484 0.266 0.484 0.703 0 0.969z">
				</path>
			</symbol>

		</defs>
	</svg>


	<iframe src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/start.html" style="display:none"></iframe>
</body>

</html>