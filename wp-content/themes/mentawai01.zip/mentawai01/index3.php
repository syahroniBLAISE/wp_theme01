<?php get_header(); ?>


				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid4ebdbad4            col-md-6 col-sm-6   znColumnElement" id="eluid4ebdbad4">


							<div
								class="znColumnElement-innerWrapper-eluid4ebdbad4 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid1293c1c0 ">
										<h1 class="tbk__title" itemprop="headline">Join the Mentawai Surf Camp Barrel.
											Start your Surf Adventure.</h1>
										<h2 class="tbk__subtitle" itemprop="alternativeHeadline">-</h2>
									</div>
									<div id="eluid64a95d22" class="zn_buttons_element eluid64a95d22 text-center "><a
											href="https://surfcampsiberut.com/#eluid703dd445" id="eluid64a95d220"
											class="eluid64a95d220 btn-element btn-element-0 btn  btn-fullcolor btn-custom-color btn-sm  zn_dummy_value btn-icon--before btn--rounded"
											data-target="smoothscroll" itemprop="url"><span>PRICE PACKAGE</span></a>
									</div>
								</div>
							</div>


						</div>

						<div class="eluidcda2ec81            col-md-6 col-sm-6   znColumnElement" id="eluidcda2ec81">


							<div
								class="znColumnElement-innerWrapper-eluidcda2ec81 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent"> </div>
							</div>


						</div>

						<div class="eluid81ae022f            col-md-12 col-sm-12   znColumnElement" id="eluid81ae022f">


							<div
								class="znColumnElement-innerWrapper-eluid81ae022f znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div class="th-spacer clearfix eluidba787014     "></div>
								</div>
							</div>


						</div>

						<div class="eluid6762db8e            col-md-3 col-sm-3   znColumnElement" id="eluid6762db8e">


							<div
								class="znColumnElement-innerWrapper-eluid6762db8e znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluideed991d9 ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Island</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>Mentawai Islands is the best place on
													earth for surfing with world class waves and Nyang-Nyang Island in
													its heart.</strong></p>
										</div>
									</div>
								</div>
							</div>


						</div>

						<div class="eluid86459c6a            col-md-3 col-sm-3   znColumnElement" id="eluid86459c6a">


							<div
								class="znColumnElement-innerWrapper-eluid86459c6a znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluid5b1c2c91 ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Waves</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>waves are in walking distance with surf
													spot in front of our camp and many more waves by boat.</strong></p>
										</div>
									</div>
								</div>
							</div>


						</div>

						<div class="eluide8056e66            col-md-3 col-sm-3   znColumnElement" id="eluide8056e66">


							<div
								class="znColumnElement-innerWrapper-eluide8056e66 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluid05a7caa5 ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Resort</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>Beachfront wooden bungalows in Mentawai
													style surrounded by nature are managed by lovely locals.</strong>
											</p>
										</div>
									</div>
								</div>
							</div>


						</div>

						<div class="eluidf91a2408            col-md-3 col-sm-3   znColumnElement" id="eluidf91a2408">


							<div
								class="znColumnElement-innerWrapper-eluidf91a2408 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-center ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--icon tbk--colored tbk-icon-pos--left-title eluid869ab51d ">
										<h3 class="tbk__title" itemprop="headline"><span class="tbk__symbol "><span
													class="tbk__icon" data-zniconfam="glyphicons_halflingsregular"
													data-zn_icon=""></span></span>Food</h3>
										<div class="tbk__text">
											<p style="text-align: left;"><strong>Three delicious meals a day with
													unlimited coffee, tea and water within all our packages will never
													leave you hungry.</strong></p>
										</div>
									</div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid5a1efe31     section-sidemargins    section--no " id="eluid5a1efe31">


				<div class="zn_section_size full_width zn-section-height--auto zn-section-content_algn--middle ">

					<div class="row gutter-0">

						<div class="eluid94cd950d            col-md-6 col-sm-6   znColumnElement" id="eluid94cd950d">


							<div
								class="znColumnElement-innerWrapper-eluid94cd950d znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="zn_custom_container eluid2683b90b  smart-cnt--default   clearfix">
										<div class="zn_col_eq_first">
											<div class="row zn_col_container-smart_container gutter-0">

												<div class="eluidc9f0374e            col-md-11 col-sm-11   znColumnElement"
													id="eluidc9f0374e">


													<div
														class="znColumnElement-innerWrapper-eluidc9f0374e znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

														<div class="znColumnElement-innerContent">
															<div
																class="th-spacer clearfix eluid374f0b28   hidden-sm hidden-xs ">
															</div>
															<div
																class="kl-title-block clearfix tbk--text- tbk--left text-left tbk-symbol--  tbk-icon-pos--after-title eluid9fc3ae52 ">
																<h2 class="tbk__title" itemprop="headline">About</h2>
																<div class="tbk__text">
																	<p>The west Sumatra have the best trip travel,
																		Surfing Mentawai,Trekking jungle
																		Mentawai,Snorkelling Around Padang Islands,Tour
																		Around West Sumatra to be found.</p>
																	<p>Let Explore West Sumatra: Come and enjoy our
																		heavenly travel destination. The west Sumatra
																		have the best trip travel, Surfing
																		Mentawai,Trekking jungle Mentawai,Snorkelling
																		Around Padang Islands,Tour Around West Sumatra
																		to be found.What are you waiting for?
																		Come,…come. Don’t refuse my invitation. It will
																		be for sure, the best ride of your life!</p>
																</div>
															</div>
															<div
																class="th-spacer clearfix eluidd17db177 hidden-lg hidden-md   ">
															</div>
														</div>
													</div>


												</div>
											</div>
										</div>
									</div><!-- /.zn_custom_container -->


								</div>
							</div>


						</div>

						<div class="eluidd861c292            col-md-6 col-sm-6   znColumnElement" id="eluidd861c292">


							<div
								class="znColumnElement-innerWrapper-eluidd861c292 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="media-container eluid366dbff3  media-container--type- kl-overlay-none  ">

										<div class="zn-bgSource ">
											<div class="zn-bgSource-image"
												style="background-image:url(<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/banner.jpg);background-repeat:repeat;background-position:center center;background-size:cover;background-attachment:scroll">
											</div>
										</div>
									</div>
									<div class="th-spacer clearfix eluid0d29baeb hidden-lg hidden-md hidden-sm  "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section
				class="zn_section eluid7f254383   zn_parallax  section-sidemargins    zn_section--relative section--no "
				id="eluid7f254383">

				<div class="zn-bgSource zn-bgSource-imageParallax js-znParallax is-fixed"
					style="height: 230px; width: 1903px; transform: translate3d(0px, 882.375px, 0px);">
					<div class="zn-bgSource-image"
						style="background-image: url(<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/mentawai-islands.jpg); background-repeat: no-repeat; background-position: center center; background-size: cover; transform: translate3d(0px, -679px, 0px);">
					</div>
					<div class="zn-bgSource-overlay" style="background-color:rgba(53,53,53,0.55)"></div>
				</div>
				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluidf0600da9            col-md-12 col-sm-12   znColumnElement" id="eluidf0600da9">


							<div
								class="znColumnElement-innerWrapper-eluidf0600da9 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluidaf6de692 ">
										<h1 class="tbk__title" itemprop="headline">Best Location in Mentawai</h1>
									</div>
									<div class="image-boxes imgbox-simple eluid44d8ea6b ">
										<div class="image-boxes-holder imgboxes-wrapper u-mb-0  ">
											<div class="image-boxes-img-wrapper img-align-center"><img
													class="image-boxes-img img-responsive "
													src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/3-flowers.png" alt="" title=""></div>
										</div>
									</div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluidcde410de  u-zindex-1   section-sidemargins    section--no "
				id="eluidcde410de">


				<div
					class="zn_section_size container custom_width zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid410f5aac            col-md-6 col-sm-5 col-xs-12  znColumnElement"
							id="eluid410f5aac">


							<div
								class="znColumnElement-innerWrapper-eluid410f5aac znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="zn_custom_container eluid3aebeaed  smart-cnt--default   clearfix">

										<div class="row zn_col_container-smart_container ">

											<div class="eluid6237d91f            col-md-12 col-sm-12   znColumnElement"
												id="eluid6237d91f">


												<div
													class="znColumnElement-innerWrapper-eluid6237d91f znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

													<div class="znColumnElement-innerContent">
														<div class="el-videobox eluid7826443b  el-videobox-Type-modal">
															<div class="fluid-width-video-wrapper"
																style="padding-top: 56.2353%;">
																<!-- <iframe class=""
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/CUsO7bmvaCE.html"
																	allowfullscreen="" id="fitvid0"></iframe> -->
																</div>
														</div>
													</div>
												</div>


											</div>
										</div>
									</div><!-- /.zn_custom_container -->


								</div>
							</div>


						</div>

						<div class="eluid6cf61102  col-lg-offset-1 col-md-offset-2 col-sm-offset-2        col-md-5 col-sm-5 col-xs-12  znColumnElement"
							id="eluid6cf61102">


							<div
								class="znColumnElement-innerWrapper-eluid6cf61102 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="th-spacer clearfix eluidd4be43d9  hidden-md hidden-sm hidden-xs "></div>
									<div
										class="kl-title-block clearfix tbk--text- tbk--left text-left tbk-symbol--  tbk-icon-pos--after-title eluid8f8c0381 ">
										<h2 class="tbk__title" itemprop="headline">Taste the vibes of Surf Camp
											Mentawais </h2>
										<div class="tbk__text">
											<p></p>
											<p>Welcome to Surf Camp. Enjoy your surf holiday while we take care of the
												rest.<br>
												The camp at the beach front of Island with traditional wooden bungalows
												is managed by a warmhearted local family. Be prepared to be treated like
												a family member and to be taken care of for an unforgettable stay.<br>
												Hospitality&nbsp;at its finest paired with a&nbsp;world class
												surf&nbsp;experience on a heavenly island is what you can expect.</p>
											<p></p>
										</div>
									</div>
									<div id="eluid107643e2" class="zn_buttons_element eluid107643e2 text-left "><a
											href="https://surfcampsiberut.com/#eluid0efaa466" id="eluid107643e20"
											class="eluid107643e20 btn-element btn-element-0 btn  btn-lined lined-dark btn-lg btn-third zn_dummy_value btn-icon--before btn--square"
											data-target="smoothscroll" itemprop="url"><span>ORDER NOW</span></a></div>
									<div class="th-spacer clearfix eluid32505abb     "></div>
									<div class="th-spacer clearfix eluidef34d963  hidden-md hidden-sm hidden-xs "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section
				class="zn_section eluid88b1cfba   zn_parallax  section-sidemargins    zn_section--relative section--no "
				id="eluid88b1cfba">

				<div class="zn-bgSource zn-bgSource-imageParallax js-znParallax is-fixed"
					style="height: 240px; width: 1903px; transform: translate3d(0px, 879.828px, 0px);">
					<div class="zn-bgSource-image"
						style="background-image: url(<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/mentawai-islands.jpg); background-repeat: no-repeat; background-position: center center; background-size: cover; transform: translate3d(0px, -677px, 0px);">
					</div>
					<div class="zn-bgSource-overlay" style="background-color:rgba(53,53,53,0.3)"></div>
				</div>
				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid82e08d3b            col-md-12 col-sm-12   znColumnElement" id="eluid82e08d3b">


							<div
								class="znColumnElement-innerWrapper-eluid82e08d3b znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluidb4106c53 ">
										<h1 class="tbk__title" itemprop="headline">BEST SERVICE EVER</h1>
									</div>
									<div class="image-boxes imgbox-simple eluidb3de4226 ">
										<div class="image-boxes-holder imgboxes-wrapper u-mb-0  ">
											<div class="image-boxes-img-wrapper img-align-center"><img
													class="image-boxes-img img-responsive "
													src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/3-flowers.png" alt="" title=""></div>
										</div>
									</div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid7c57ccf6  u-zindex-1   section-sidemargins    section--no "
				id="eluid7c57ccf6">


				<div
					class="zn_section_size container custom_width zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid69ebacde            col-md-6 col-sm-5 col-xs-12  znColumnElement"
							id="eluid69ebacde">


							<div
								class="znColumnElement-innerWrapper-eluid69ebacde znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="zn_custom_container eluidc0226fbc  smart-cnt--default   clearfix">

										<div class="row zn_col_container-smart_container ">

											<div class="eluide25fb3dd            col-md-12 col-sm-12   znColumnElement"
												id="eluide25fb3dd">


												<div
													class="znColumnElement-innerWrapper-eluide25fb3dd znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

													<div class="znColumnElement-innerContent">
														<div class="eluidc6631c07  zn-SliderEl clearfix zn-SliderEl--view"
															id="eluidc6631c07">
															<div
																class="zn-SliderNav zn-SliderNav--pos-middle zn-SliderNav--style1 zn-SliderNav--size-normal zn-SliderNav--round-yes zn-SliderNav--theme-dark">
																<span class="znSlickNav-arr znSlickNav-prev slick-arrow"
																	style="display: block;"><svg viewBox="0 0 256 256">
																		<polyline fill="none" stroke="black"
																			stroke-width="16" stroke-linejoin="round"
																			stroke-linecap="round"
																			points="184,16 72,128 184,240"></polyline>
																	</svg></span><span
																	class="znSlickNav-arr znSlickNav-next slick-arrow"
																	style="display: block;"><svg viewBox="0 0 256 256">
																		<polyline fill="none" stroke="black"
																			stroke-width="16" stroke-linejoin="round"
																			stroke-linecap="round"
																			points="72,16 184,128 72,240"></polyline>
																	</svg></span></div>
															<div class="zn-Slider zn-Slider-eluidc6631c07 zn-Slider--cols1 js-slick mfp-gallery mfp-gallery--misc slick-initialized slick-slider slickSlider--activated"
																data-slick="{&quot;slidesToShow&quot;:1,&quot;responsive&quot;:[],&quot;autoplay&quot;:true,&quot;appendArrows&quot;:&quot;.eluidc6631c07 .zn-SliderNav&quot;}">
																<div class="slick-list draggable">
																	<div class="slick-track"
																		style="opacity: 1; width: 5390px; transform: translate3d(-1540px, 0px, 0px);">
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="-1"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg"
																					title="pantai_mapadegat_kepulauan_mentawai"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="433"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/pantai_mapadegat_kepulauan_mentawai-768x433.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-768x433.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-280x158.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg 790w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide"
																			data-title="" data-slick-index="0"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg"
																					title="5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="432"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1024x576.jpg 1024w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-280x157.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1170x658.jpg 1170w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg 1265w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-current slick-active slick-item--activated"
																			data-title="" data-slick-index="1"
																			aria-hidden="false" style="width: 770px;"
																			tabindex="0">
																			<div class="zn-Slider-itemInner"><a
																					href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																					title="kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="0"><img width="700"
																						height="393"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg 700w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-300x168.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-280x157.jpg 280w"
																						sizes="(max-width: 700px) 100vw, 700px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide"
																			data-title="" data-slick-index="2"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg"
																					title="pantai_mapadegat_kepulauan_mentawai"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="433"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/pantai_mapadegat_kepulauan_mentawai-768x433.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-768x433.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-280x158.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg 790w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="3"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg"
																					title="5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="432"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-768x432.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1024x576.jpg 1024w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-280x157.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711-1170x658.jpg 1170w, https://surfcampsiberut.com/wp-content/uploads/2023/03/5aa8d1a07c59b-kawasan-aloita-resort-di-pulau-simakakang-kabupaten-kepulauan-mentawai_1265_711.jpg 1265w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="4"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																					title="kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="700"
																						height="393"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2.jpg 700w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-300x168.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/kabupaten-kepulauan-mentawai-3-63533dbc4addee6ea67846f2-280x157.jpg 280w"
																						sizes="(max-width: 700px) 100vw, 700px"></a>
																			</div>
																		</div>
																		<div class="zn-Slider-item slick-slide slick-cloned"
																			data-title="" data-slick-index="5"
																			aria-hidden="true" style="width: 770px;"
																			tabindex="-1">
																			<div class="zn-Slider-itemInner"><a
																					href="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg"
																					title="pantai_mapadegat_kepulauan_mentawai"
																					class="zn-Slider-link"
																					data-lightbox="mfp" data-mfp="image"
																					tabindex="-1"><img width="768"
																						height="433"
																						src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/pantai_mapadegat_kepulauan_mentawai-768x433.jpg"
																						class="zn-Slider-img" alt=""
																						srcset="https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-768x433.jpg 768w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-300x169.jpg 300w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai-280x158.jpg 280w, https://surfcampsiberut.com/wp-content/uploads/2023/03/pantai_mapadegat_kepulauan_mentawai.jpg 790w"
																						sizes="(max-width: 768px) 100vw, 768px"></a>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>


											</div>
										</div>
									</div><!-- /.zn_custom_container -->


								</div>
							</div>


						</div>

						<div class="eluidc029ac95  col-lg-offset-1 col-md-offset-2 col-sm-offset-2        col-md-5 col-sm-5 col-xs-12  znColumnElement"
							id="eluidc029ac95">


							<div
								class="znColumnElement-innerWrapper-eluidc029ac95 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div class="th-spacer clearfix eluid8cdb7457  hidden-md hidden-sm hidden-xs "></div>
									<div
										class="kl-title-block clearfix tbk--text- tbk--left text-left tbk-symbol--  tbk-icon-pos--after-title eluid05a5a489 ">
										<h2 class="tbk__title" itemprop="headline">Touch the atmosphere of Mentawai
											Islands.</h2>
										<div class="tbk__text">
											<p></p>
											<p>We have surf camp that serve either as shared rooms or can be booked as
												private rooms and Dorm Western style toilets and showers are shared.
												Mosquito nets, fans, towels and sockets are provided.<br>
												Our family knows the waves, the winds, the weather and the islands
												better than anybody else, since we were living here for generations as
												fishermen, basically growing up in the waters.<br>
												And it seems like many of our guests like the way we treat them since
												they return to us regularly for another stay. We are very proud of that!
											</p>
											<p></p>
										</div>
									</div>
									<div id="eluid836349e2" class="zn_buttons_element eluid836349e2 text-left "><a
											href="https://wa.me/6281374006060" id="eluid836349e20"
											class="eluid836349e20 btn-element btn-element-0 btn  btn-lined lined-dark btn-lg btn-third zn_dummy_value btn-icon--before btn--square"
											data-target="smoothscroll" itemprop="url"><span>ORDER NOW</span></a></div>
									<div class="th-spacer clearfix eluided3ac01f     "></div>
									<div class="th-spacer clearfix eluidf84d1c90  hidden-md hidden-sm hidden-xs "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid301682de     section-sidemargins    section--no " id="eluid301682de">


				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluidb444505a            col-md-12 col-sm-12   znColumnElement" id="eluidb444505a">


							<div
								class="znColumnElement-innerWrapper-eluidb444505a znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid316859a4 ">
										<h2 class="tbk__title" itemprop="headline">Feel the words of our guests.</h2>
									</div>
								</div>
							</div>


						</div>

						<div class="eluidcbf748b5  col-lg-offset-3          col-md-6 col-sm-6   znColumnElement"
							id="eluidcbf748b5">


							<div
								class="znColumnElement-innerWrapper-eluidcbf748b5 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid4a1d95f9 ">
										<h3 class="tbk__title" itemprop="headline">TESTIMONY</h3>
									</div>
									<div
										class="testimonials-carousel tst-carousel eluidef1b9cc4  tstsld--light element-scheme--light">
										<div class="tst-carousel-controls"><span
												class="znSlickNav-arr znSlickNav-prev slick-arrow"
												style="display: inline;"><svg viewBox="0 0 256 256">
													<polyline fill="none" stroke="black" stroke-width="16"
														stroke-linejoin="round" stroke-linecap="round"
														points="184,16 72,128 184,240"></polyline>
												</svg></span><span class="znSlickNav-arr znSlickNav-next slick-arrow"
												style="display: inline;"><svg viewBox="0 0 256 256">
													<polyline fill="none" stroke="black" stroke-width="16"
														stroke-linejoin="round" stroke-linecap="round"
														points="72,16 184,128 72,240"></polyline>
												</svg></span></div>
										<ul class="tst-carousel-list js-slick slick-initialized slick-slider"
											data-slick="{&quot;infinite&quot;:true,&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1,&quot;autoplay&quot;:true,&quot;autoplaySpeed&quot;:&quot;2500&quot;,&quot;arrows&quot;:true,&quot;appendArrows&quot;:&quot;.eluidef1b9cc4 .tst-carousel-controls&quot;,&quot;dots&quot;:false}">
											<div class="slick-list draggable">
												<div class="slick-track"
													style="opacity: 1; width: 2775px; transform: translate3d(-1665px, 0px, 0px); transition: transform 500ms ease 0s;">
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-cloned"
														data-slick-index="-1" aria-hidden="true" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>If you want to live a
																good real experience into mentawai, this is the place to
																stay. Good food, good acomodation into an awesome
																atmosphere. Aldi the owner will make sure you feel like
																home! Really recommend it.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/STUDIO-SHODWE.-SURFING-CLUB-AND-APPARELS-7-1-e1678370187674-40x40_c.png"
																	width="40" height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Hegoi</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-current slick-active"
														data-slick-index="0" aria-hidden="false" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>I felt at home. They
																took us surfing everywhere, they taught us all the ways
																through the jungle, they waited for us all day with
																freshly made food, they took care of us and our things,
																they motivated us to go fishing, they went to buy things
																on another island. They went fishing every day, they
																helped me repair my board and above all, they always had
																tremendous energy all the time, a total commitment to
																this family.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/juan-40x40_c.jpg" width="40"
																	height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Raul</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide"
														data-slick-index="1" aria-hidden="true" tabindex="0"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>If you want to live a
																good real experience into mentawai, this is the place to
																stay. Good food, good acomodation into an awesome
																atmosphere. Aldi the owner will make sure you feel like
																home! Really recommend it.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/STUDIO-SHODWE.-SURFING-CLUB-AND-APPARELS-7-1-e1678370187674-40x40_c.png"
																	width="40" height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Hegoi</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-cloned"
														data-slick-index="2" aria-hidden="true" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>I felt at home. They
																took us surfing everywhere, they taught us all the ways
																through the jungle, they waited for us all day with
																freshly made food, they took care of us and our things,
																they motivated us to go fishing, they went to buy things
																on another island. They went fishing every day, they
																helped me repair my board and above all, they always had
																tremendous energy all the time, a total commitment to
																this family.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/juan-40x40_c.jpg" width="40"
																	height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Raul</h5>
														</div>
													</li>
													<li class="tst-carousel-item u-slick-show1stOnly slick-slide slick-cloned"
														data-slick-index="3" aria-hidden="true" tabindex="-1"
														style="width: 555px;">
														<blockquote class="tst-carousel-bqt"><b>If you want to live a
																good real experience into mentawai, this is the place to
																stay. Good food, good acomodation into an awesome
																atmosphere. Aldi the owner will make sure you feel like
																home! Really recommend it.</b></blockquote>
														<div class="testimonial-author tst-carousel-author">
															<div class="testimonial-author--photo tst-carousel-photo">
																<img class="tst-carousel-img"
																	src="<?php echo bloginfo("stylesheet_directory"); ?>/fileTheme/STUDIO-SHODWE.-SURFING-CLUB-AND-APPARELS-7-1-e1678370187674-40x40_c.png"
																	width="40" height="40" alt="" title=""></div>
															<h5 class="tst-carousel-title">Hegoi</h5>
														</div>
													</li>
												</div>
											</div>
										</ul>
									</div>
									<div class="th-spacer clearfix eluidf95400fd     "></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			<section class="zn_section eluid703dd445     section-sidemargins    section--no " id="eluid703dd445">


				<div class="zn_section_size container zn-section-height--auto zn-section-content_algn--top ">

					<div class="row ">

						<div class="eluid9cec0bc6            col-md-12 col-sm-12   znColumnElement" id="eluid9cec0bc6">


							<div
								class="znColumnElement-innerWrapper-eluid9cec0bc6 znColumnElement-innerWrapper znColumnElement-innerWrapper--valign-top znColumnElement-innerWrapper--halign-left ">

								<div class="znColumnElement-innerContent">
									<div
										class="kl-title-block clearfix tbk--text- tbk--center text-center tbk-symbol--  tbk-icon-pos--after-title eluid7639ee48 ">
										<h2 class="tbk__title" itemprop="headline">Book now</h2>
										<h4 class="tbk__subtitle" itemprop="alternativeHeadline">You have chosen a
											package and want to stay with us? Or you still have questions?

											Contact us.</h4>
									</div>
									<div id="eluidda12940e" class="zn_buttons_element eluidda12940e text-center "><a
											href="tel:+6281374006060" id="eluidda12940e0"
											class="eluidda12940e0 btn-element btn-element-0 btn  btn-fullcolor btn-custom-color btn-md  zn_dummy_value btn-icon--before btn--rounded"
											target="_blank" rel="noopener" itemprop="url"><span class="btn-element-icon"
												data-zniconfam="glyphicons_halflingsregular"
												data-zn_icon=""></span><span>+62 00000000000</span></a></div>
								</div>
							</div>


						</div>

					</div>
				</div>

			</section>


			


	
	<?php get_footer(); ?>