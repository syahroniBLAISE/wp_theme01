<?php get_header(); ?>
    <article class="content px-3 py-5 p-md-5">
		<h1>Page Not Found</h1>
    </article>

<?php get_footer(); ?>
