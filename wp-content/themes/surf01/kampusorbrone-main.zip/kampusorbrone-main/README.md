# kampusorbrone
 KampuSORBORNE Wp Theme

Ini adalah tema WordPress yang saya buat sebagai bahan pembelajaran dan tutorial cara membuat theme WordPress.
Video-video tutorialnya ada di YouTube: https://www.youtube.com/watch?v=tYWKEZA6jNI&list=PLT2PgOHCtd7ZH0ODErLRunkB1Jo6R6h8v
