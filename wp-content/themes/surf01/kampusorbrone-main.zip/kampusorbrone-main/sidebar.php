<?php if(is_active_sidebar('kampusorborne_sidebar')) : ?>
<?php dynamic_sidebar('kampusorborne_sidebar'); ?>
<?php endif; ?>